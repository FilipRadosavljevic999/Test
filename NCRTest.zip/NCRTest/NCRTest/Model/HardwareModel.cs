﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NCRTest.Model
{
    public class HardwareModel
    {
        public string Id { get; set; }
        public string Model { get; set; }
        public string AdditionalInfo { get; set; }
        public List<RecordModel> RecordModel { get; set; }
    }
}
