﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NCRTest.ErrorsLog
{
    public class ErrorLog
    {
        public static void LogginError(Exception ex)
        {
            DateTime date = DateTime.Now;
            string msg = String.Format("{0}\t{1}\t{2}\n", ex.Message, ex.StackTrace, date);
            File.WriteAllText("Log.txt", msg);
        }
    }
}
