﻿using NCRTest.DB;
using NCRTest.ErrorsLog;
using NCRTest.Model;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NCRTest.ExportData
{
    public class Export
    {
        public void ExportData()
        {
            try
            {
                var list = DatabaseInitializer.GetHardwareType();
                if (list == null)
                {
                    throw new NullReferenceException();
                }
                List<HardwareModel> forExport = new List<HardwareModel>();
                foreach (HardwareModel model in list)
                {
                    HardwareModel hardwareTypeModel = new HardwareModel();
                    hardwareTypeModel.Model = model.Model;
                    hardwareTypeModel.AdditionalInfo = model.AdditionalInfo;
                    hardwareTypeModel.RecordModel = DatabaseInitializer.GetRecords(model.Id);
                    if (hardwareTypeModel.Model != null)
                    {
                        forExport.Add(hardwareTypeModel);
                    }

                }

                string classText = "";
                foreach (var item in forExport)
                {
                    classText += $"Model: {item.Model}\nAdditionalInfo: {item.AdditionalInfo}\n";
                    classText += "Record:\n";
                    foreach (var record in item.RecordModel)
                    {
                        classText += $"Value: {record.Value} ,Created: {record.Created}\n";
                    }
                    ;

                }
                File.WriteAllText("Hardware.txt", classText);
            }
            catch (Exception ex)
            {
                ErrorLog.LogginError(ex);
            }


        }
    }
}
