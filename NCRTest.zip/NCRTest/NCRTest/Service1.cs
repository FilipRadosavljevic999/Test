﻿using NCRTest.DB;
using NCRTest.UtilizationFolder;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Timers;

namespace NCRTest
{
    public partial class Service1 : ServiceBase
    {
        Timer _timer = new Timer();
        Utilization ut = new Utilization();
        public Service1()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            try
            {
                DatabaseInitializer.InitializeDatabase();
                if (DatabaseInitializer.CheckIfAlreadyExistHardwareType())
                {
                    DatabaseInitializer.DeleteHardwareType();
                }
                ut.InsertHardwareTypeProcessor();
                ut.InsertHardwareTypeDisk();
                ut.InsertHardwareTypeMemory();
                _timer.Interval = ConfigurationClass.MilisecondIntervalForTimer;
                _timer.Elapsed += TimerElapsed;
                _timer.Start();
            }
            catch (Exception ex)
            {
                ErrorsLog.ErrorLog.LogginError(ex);
            }
            
        }
        private void TimerElapsed(object sender, ElapsedEventArgs e)
        {
            ut.InsertProcessorUtilization();
            ut.InsertDiskUtilization();
            ut.InsertMemoryUtilization();
        }
        protected override void OnStop()
        {
            try
            {
                _timer.Stop();
                _timer.Dispose();
            }
            catch(Exception ex) 
            {
                ErrorsLog.ErrorLog.LogginError(ex);
            }
           
        }

        private void eventLog1_EntryWritten(object sender, EntryWrittenEventArgs e)
        {

        }
    }
}
